#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

int func();

int main() {
	int cnt;

	scanf("%d", &cnt);
	fgetc(stdin);

	for (int i = 0; i < cnt; ++i) {
		printf("%d\n", func());
	}

	return 0;
}

int func() {
	int cnt;

	scanf("%d", &cnt);
	fgetc(stdin);

	string origin;
	string trans;

	getline(cin, origin);
	getline(cin, trans);
	
	//printf("%s %s\n", origin.c_str(), trans.c_str());

	if (origin.compare(trans) == 0) {
		return 0;
	}

	for (int i = 1; i < cnt / 2 + 1; ++i) {
		string s1 = origin.substr(0, i);
		string s2 = origin.substr(i);

		string s3 = trans.substr(0, i);
		string s4 = trans.substr(i);

		if ((s2 + s1).compare(trans) == 0) {
			return cnt - i;
		}
		else if((s4 + s3).compare(origin) == 0) {
			//cout << s1 << endl
			//	<< s3 << endl
			//	<< endl
			//	<< s2 << endl
			//	<< s4 << endl
			//	<< endl;

			return i;
		}
		

	}

	return -1;
}